import axios from "axios";

const API_BASE_URL = "https://shy-kathy-kazim68-5d662330.koyeb.app"; // Replace with your backend URL

const authApi = {
  register: async (userData) => {
    const response = await axios.post(
      `${API_BASE_URL}/auth/register`,
      userData
    );
    return response.data;
  },

  // New login method
  login: async (credentials) => {
    const response = await axios.post(`${API_BASE_URL}/auth/login`, credentials);
    return response.data;
  },

  verifyOtp: async (data) => {
    const res = await axios.post(`${API_BASE_URL}/auth/verify-email`, data);
    return res.data;
  },
  resendOtp: async (email) => {
    const res = await axios.post(`${API_BASE_URL}/auth/resend-otp`, { email });
    return res.data;
  },  
};

export default authApi;
